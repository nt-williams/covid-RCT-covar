
#' Chemotherapy for Stage B/C colon cancer
"colon"
