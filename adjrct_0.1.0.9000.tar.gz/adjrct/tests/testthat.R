library(testthat)
library(survrct)

test_check("survrct")
